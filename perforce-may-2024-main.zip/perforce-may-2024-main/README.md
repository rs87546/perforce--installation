# perforce-may-2024

## Kindly share your feedback here
<pre>
https://survey.zohopublic.com/zs/tdD397
</pre>

## RPS Cloud Lab Url
```
https://cloud.cdp.rpsconsulting.in/
```

## Lab machine allotment
```
Username        Password   Participant Name
24MAN0064-01    rps@2345   Kunal
24MAN0064-02    rps@2345   Abdul Reheman
24MAN0064-03    rps@2345   Raghunath
24MAN0064-04    rps@2345   Ashwini Prakash
24MAN0064-05    rps@2345   Nataraj
24MAN0064-06    rps@2345   Rajesh
24MAN0064-07    rps@2345   Anurag
24MAN0064-08    rps@2345   Yatish
24MAN0064-09    rps@2345   Suresh
24MAN0064-10    rps@2345   Manikandan
24MAN0064-11    rps@2345   Pramod
24MAN0064-12    rps@2345   Gnanesh
24MAN0064-13    rps@2345   Thejaswini
```

Ubuntu Login Credentials
```
username - rps
password - rps@123
```
